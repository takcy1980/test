package com.pse.fotoz.dbal;

/**
 * Exception occuring from erronous Hibernate operation.
 * @author Robert
 */
public class HibernateException extends Exception {}
